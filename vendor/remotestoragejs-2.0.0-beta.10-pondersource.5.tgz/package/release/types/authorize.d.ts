import type RemoteStorage from './remotestorage';
import { Remote } from "./remote";
interface AuthResult {
    access_token?: string;
    refresh_token?: string;
    code?: string;
    scope?: string;
    rsDiscovery?: object;
    error?: string;
    remotestorage?: string;
    state?: string;
}
export interface AuthorizeOptions {
    /** URL of the authorization endpoint */
    authURL: string;
    /** access scope */
    scope?: string;
    redirectUri?: string;
    /**
    * client identifier
    * @defaultValue Origin of the redirectUri
    * */
    clientId?: string;
    response_type?: 'token' | 'code';
    state?: string;
    code_challenge?: string;
    code_challenge_method?: 'S256' | 'plain';
    token_access_type?: 'online' | 'offline';
}
/**
 * What the token request needs after the redirect back from the authorization
 * server (a full page load), kept in sessionStorage.
 */
export interface PkceTransaction {
    codeVerifier: string;
    /** The random state sent to the authorization server */
    state: string;
    /** Token endpoint; the remote's TOKEN_URL when not set (Dropbox) */
    tokenURL?: string;
    /** Client id; the remote's clientId when not set (Dropbox) */
    clientId?: string;
    /** The app's location hash before the redirect, restored afterwards */
    appState?: string;
}
/** What a token endpoint returns for a refresh token */
export interface RefreshedToken {
    token: string;
    tokenType?: string;
    /** A rotated refresh token, when the server issues one */
    refreshToken?: string;
}
export declare class Authorize {
    static IMPLIED_FAKE_TOKEN: boolean;
    /**
     * Navigates browser to provider's OAuth page. When user grants access,
     * browser will navigate back to redirectUri and OAuth will continue
     * with onFeaturesLoaded.
     */
    static authorize(remoteStorage: RemoteStorage, options: AuthorizeOptions): void;
    /**
     * Store a PKCE transaction before redirecting to the authorization server,
     * replacing any earlier one (e.g. from an abandoned authorization). The
     * current location hash is kept so it can be restored afterwards, since the
     * state parameter carries the random value instead.
     *
     * Throws when sessionStorage rejects the writes, after removing what it
     * can; nothing is written when the earlier transaction can't be removed.
     */
    static savePkceTransaction(transaction: PkceTransaction): void;
    /**
     * Read and remove the stored PKCE transaction, so a code is exchanged at
     * most once and nothing outlives it. Returns null when there is none.
     */
    static takePkceTransaction(): PkceTransaction | null;
    /** Remove any stored PKCE transaction. */
    static clearPkceTransaction(): void;
    /** On success, calls remote.configure() with new access token */
    static refreshAccessToken(rs: RemoteStorage, remote: Remote, refreshToken: string): Promise<void>;
    /**
     * Exchange a refresh token for a new access token, without touching any
     * remote, so the caller decides whether the result still applies.
     *
     * Throws `Unauthorized` only when the server rejects the refresh token
     * (`invalid_grant`, RFC 6749 §5.2). Any other failure, such as a server
     * error, rate limiting or a network error, says nothing about the refresh
     * token, and throws a plain error.
     */
    static requestRefreshedToken(tokenURL: string, clientId: string, refreshToken: string): Promise<RefreshedToken>;
    /**
     * Get current document location
     *
     * Override this method if access to document.location is forbidden
     */
    static getLocation: () => Location;
    /**
     * Open new InAppBrowser window for OAuth in Cordova
     */
    static openWindow: (url: string, redirectUri: string, options: string) => Promise<AuthResult | string | void>;
    /**
     * Set current document location
     *
     * Override this method if access to document.location is forbidden
     */
    static setLocation(location: string | Location): void;
    static _rs_supported(): boolean;
    static _rs_init: (remoteStorage: RemoteStorage) => void;
    static _rs_cleanup(remoteStorage: RemoteStorage): void;
}
export default Authorize;
//# sourceMappingURL=authorize.d.ts.map