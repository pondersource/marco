interface ChangeResponse {
    status: number;
    responseText: string;
}
/** Account-wide change cursor and conservative synthetic folder validators. @internal */
export declare class GoogleDriveChanges {
    private request;
    private onChange;
    revision?: string;
    private instance;
    private token?;
    private serial;
    private epoch;
    private listed;
    private pending?;
    constructor(request: (url: string) => Promise<ChangeResponse>, onChange: () => void);
    get generation(): number;
    reset(): void;
    invalidate(): void;
    markListed(path: string, revision: string): void;
    getRevision(path: string): string | undefined;
    prepare(): Promise<void>;
    private read;
    private parse;
    private refresh;
}
export {};
//# sourceMappingURL=googledrive-changes.d.ts.map